Sossoldi press kit — generated 2026-11-04

Contents
  boilerplate-en.md / boilerplate-it.md  short description, ready to paste
  fact-sheet.md                          facts, colours, typography
  sossoldi-icon.png                      512×512 app icon
  sossoldi-cover.jpg                     project cover
  screens/                               five screenshots of the released app
  palette.css                            design tokens (single source of truth)

The screenshots are real captures of the released app, not mockups.
Please link to https://sossoldi.com rather than copying pages.
Press contact: help.sossoldi@gmail.com

Sossoldi is a free and open source wealth management app for iOS and Android. It tracks accounts, investments, budgets and recurring payments, and turns them into one number: your net worth. Everything is stored on the device — there is no account to create, no subscription and no Sossoldi server. Built with Flutter and released under the MIT licence, Sossoldi is developed in the open by a community of contributors, with a public roadmap and public discussions. The app is available on the App Store, Google Play and F-Droid.

Website: https://sossoldi.com
Source code: https://github.com/RIP-Comm/sossoldi
Licence: MIT

# Sossoldi — fact sheet

- Name: Sossoldi
- What it is: wealth management, personal finance and net worth tracking app
- Platforms: iOS (App Store), Android (Google Play, F-Droid)
- Licence: MIT
- Price: free, no paid tier, no advertising
- App languages: English; Italian and Portuguese in progress
- First release: 0.1.0-beta, 4 December 2024
- Stable release: 1.0.0, 20 August 2026
- Source code: https://github.com/RIP-Comm/sossoldi
- Website: https://sossoldi.com
- Press contact: help.sossoldi@gmail.com

## Description (100 words)

Sossoldi is a free and open source wealth management app for iOS and Android. It tracks accounts, investments, budgets and recurring payments, and turns them into one number: your net worth. Everything is stored on the device — there is no account to create, no subscription and no Sossoldi server. Built with Flutter and released under the MIT licence, Sossoldi is developed in the open by a community of contributors, with a public roadmap and public discussions. The app is available on the App Store, Google Play and F-Droid.

## Colours

- Ink #00152D
- Paper #F1F5F9
- Structure #023B79
- Positive #248731
- Negative #C52626

## Typography

Nunito Sans, weights 300–900 (OFL). Wordmark set in Nunito Sans Black.

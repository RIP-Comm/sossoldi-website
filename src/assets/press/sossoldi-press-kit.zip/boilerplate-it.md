Sossoldi è un'app gratuita e open source per gestire il patrimonio su iOS e Android. Tiene traccia di conti, investimenti, budget e pagamenti ricorrenti, e li riduce a un solo numero: il patrimonio netto. Tutto resta sul dispositivo: non c'è un account da creare, non c'è un abbonamento, non c'è un server Sossoldi. Scritta in Flutter e rilasciata con licenza MIT, è sviluppata apertamente da una community di contributor, con roadmap e discussioni pubbliche. L'app è disponibile su App Store, Google Play e F-Droid.

Sito: https://sossoldi.com
Codice sorgente: https://github.com/RIP-Comm/sossoldi
Licenza: MIT
